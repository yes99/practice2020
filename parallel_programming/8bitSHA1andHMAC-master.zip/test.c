#include <stdio.h>
#include <string.h>

#include "sha1.h"
#include "hmac.h"

#ifndef byte
	#define byte unsigned char
#endif

void printArray(byte msg[]) {
  byte n ;
  for(byte k = 0; k<4; k++) {
  	n = msg[k];
    for(byte i = 7; i>=0; i--) {
      if ((n>>i) & 1){
        printf("1");
      } else {
        printf("0");
      }
    }
    printf("");
  }
}

void printHex(byte msg[], byte length){
	printf("0x");
	for(byte i=0; i<length; i++){
		if (msg[i]>0x0f){
			printf("%x", msg[i]);
		} else {
			printf("0%x", msg[i]);
		}		
	}
	printf("\n");
}

int main() {
  byte digest[20];
  char mystr[1024];
  printf("SHA1\n");
  scanf("%s", mystr);

  sha1((const byte *) mystr,strlen(mystr), digest);
  printHex(digest, 20); printf("\n");

}
  
